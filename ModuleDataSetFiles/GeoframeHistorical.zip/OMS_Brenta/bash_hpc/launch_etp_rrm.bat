@echo off
call %CONDA_ACTIVATE% geoframe_trento

:: split meteo to ID folders
cd /d ..\Jupyter\6_rainfall_runoff_model\
echo Current directory: %cd%

python make_meteo_input.py %OMS_BRENTA_FOLDER%
:: move init states from initState_files folder to ID folders
:: cd /d ..\Jupyter\6_rainfall_runoff_model\

python move_init_to_ID_folders.py -f initState_files -m %OMS_BRENTA_FOLDER%

cd /d ..\
echo Current directory: %cd%
cd /d ..\
echo Current directory: %cd%

:: python -m nbconvert --to notebook --execute --inplace Jupyter/5_evapotranspiration/5_1_create_sim_files_evapotranspiration.ipynb
:: python -m nbconvert --to notebook --execute --inplace Jupyter/6_rainfall_runoff_model/6_1_create_sim_files_rainfall_runoff_model.ipynb

python -m nbconvert --to notebook --execute --inplace %OMS_BRENTA_FOLDER%/Jupyter/5_evapotranspiration/5_1_create_sim_files_evapotranspiration.ipynb
python -m nbconvert --to notebook --execute --inplace %OMS_BRENTA_FOLDER%/Jupyter/6_rainfall_runoff_model/6_1_create_sim_files_rainfall_runoff_model.ipynb

:: cd /d %OMS_BRENTA_FOLDER%/
echo Current directory: %cd%

java -version

:: this is with current dir
java -Xmx28G -Doms3.work="%CD%/" -cp ".;oms-3.6.28-console/oms-all.jar;lib/*;dist/*" oms3.CLI -r simulation/compiled/et/graph.sim
java -Xmx28G -Doms3.work="%CD%/" -cp ".;oms-3.6.28-console/oms-all.jar;lib/*;dist/*" oms3.CLI -r simulation/compiled/RRM/graph_brenta.sim

:: java -Xmx28G -Doms3.work="%OMS_BRENTA_FOLDER%/" -cp ".;oms-3.6.28-console/oms-all.jar;lib/*;dist/*" oms3.CLI -r %OMS_BRENTA_FOLDER%/simulation/compiled/et/graph.sim
:: java -Xmx28G -Doms3.work="%OMS_BRENTA_FOLDER%/" -cp ".;oms-3.6.28-console/oms-all.jar;lib/*;dist/*" oms3.CLI -r %OMS_BRENTA_FOLDER%/simulation/compiled/RRM/graph_brenta.sim

:: move final states from ID folders to finalState_files folder
echo Current directory: %cd%
cd /d %~dp0
cd /d ..\
cd /d Jupyter\6_rainfall_runoff_model\
echo Current directory: %cd%

python move_init_to_state_folder.py -f finalState_files -m %OMS_BRENTA_FOLDER%

:: merge output in one file
python make_output.py %OMS_BRENTA_FOLDER%

:: call conda deactivate
