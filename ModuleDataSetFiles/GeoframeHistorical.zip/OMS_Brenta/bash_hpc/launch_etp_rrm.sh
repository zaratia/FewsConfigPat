#!/bin/bash 

# imposta il numero di nodi e i core e la ram da utilizzare per ciascun nodo
# in questo caso 12 core e 23 GB di RAM per ciascuno dei 5 nodi
# per un totale di 60 core e 115 GB di RAM
#PBS -l select=1:ncpus=12:mem=28GB

#PBS -N ETP

#PBS -l walltime=6:00:00

# imposta la coda di esecuzione
#PBS -q shortCPUQ


# da modificare 

source /Users/formeppe/anaconda3/etc/profile.d/conda.sh

conda activate geoframe_trento
 
cd /Users/formeppe/Downloads/OMS_Project_Brenta_TempoRealexFEWS/

jupyter execute Jupyter/5_evapotranspiration/5_1_create_sim_files_evapotranspiration.ipynb
jupyter execute Jupyter/6_rainfall_runoff_model/6_1_create_sim_files_rainfall_runoff_model.ipynb

java -version
java -Xmx28G \
    -Doms3.work=/Users/formeppe/Downloads/OMS_Project_Brenta_TempoRealexFEWS/ \
    -cp ".:oms-3.6.28-console/oms-all.jar:lib/*:dist/*" oms3.CLI \
    -r simulation/compiled/et/graph.sim
    
java -Xmx28G \
    -Doms3.work=/Users/formeppe/Downloads/OMS_Project_Brenta_TempoRealexFEWS/ \
    -cp ".:oms-3.6.28-console/oms-all.jar:lib/*:dist/*" oms3.CLI \
    -r simulation/compiled/RRM/graph_brenta.sim