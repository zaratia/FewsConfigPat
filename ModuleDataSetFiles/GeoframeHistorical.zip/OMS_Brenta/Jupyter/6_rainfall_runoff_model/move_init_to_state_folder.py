import os
import json
import shutil
import argparse
import zipfile

# parse init o final forlder
argparse.ArgumentParser()
# Crea il parser
parser = argparse.ArgumentParser(description="")
parser.add_argument("-f", "--folder", type=str, help="initState_files o finalState_files")
parser.add_argument("-m", "--home_dir_mod", type=str, help="model installation directory")
# Leggi gli argomenti dalla riga di comando
args = parser.parse_args()

home_dir_mod = args.home_dir_mod

# 4. Usa il parametro nel codice
print(f"State folder: {args.folder}")
print(f"Model folder: {args.home_dir_mod}")

# --- CONFIGURAZIONE ---
json_path = os.path.join(
    home_dir_mod, "Jupyter", "6_rainfall_runoff_model", "RRM.json"
)        # percorso al tuo file json
home_dir = os.path.abspath(
    os.path.join(os.path.dirname(os.getcwd()), '..')
)  # valore da sostituire a ${home}

output_base = os.path.join(home_dir_mod, "output")  # cartella con le sottocartelle ID
dest_folder = os.path.join(home_dir, args.folder)  # cartella di destinazione unica
print('home_dir: ', home_dir)
print('home_dir_mod: ', home_dir_mod)
print('dest_folder', dest_folder)
move_files = False                # True = sposta, False = copia

zip_path = os.path.join(dest_folder, "finalState_files.zip")

os.makedirs(dest_folder, exist_ok=True)

# --- LETTURA JSON ---
with open(json_path, "r") as f:
    config = json.load(f)

# --- TROVA LE CHIAVI CON 'initState' ---
init_state_keys = {k: v for k, v in config.items() if "initState" in k}

print("Chiavi trovate con 'initState':")
for k, v in init_state_keys.items():
    print(f"  {k}: {v}")

# --- TROVA TUTTI GLI ID DISPONIBILI (sottocartelle di output/) ---
if not os.path.isdir(output_base):
    raise FileNotFoundError(f"Cartella non trovata: {output_base}")

ids = [d for d in os.listdir(output_base) if os.path.isdir(os.path.join(output_base, d))]
print(f"\nTrovati {len(ids)} ID: {ids}")

# --- COSTRUZIONE PERCORSI E SPOSTAMENTO ---
moved_count = 0
missing_files = []

for id_val in ids:
    for key, template_path in init_state_keys.items():
        # sostituzione dei placeholder
        real_path = template_path.replace("${home}", home_dir_mod).replace("${ID}", id_val)
        real_path = os.path.normpath(real_path)
        if os.path.isfile(real_path):
            filename = os.path.basename(real_path)
            dest_path = os.path.join(dest_folder, filename)            
            if move_files:
                shutil.move(real_path, dest_path)
            else:
                shutil.copy2(real_path, dest_path)

            moved_count += 1
        else:
            missing_files.append(real_path)

print(f"\nFile spostati/copiati: {moved_count}")
if missing_files:
    print(f"File non trovati ({len(missing_files)}):")
    # for mf in missing_files:
    #     print(f"  {mf}")
else:
    print("Nessun file mancante, tutto ok!")

# --- COMPRESSIONE IN UN UNICO ARCHIVIO ZIP ---

print(f"\nCreazione archivio {zip_path}...")

with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zipf:
    for filename in os.listdir(dest_folder):
        file_path = os.path.join(dest_folder, filename)
        if os.path.isfile(file_path) and filename.endswith(".csv"):
            zipf.write(file_path, arcname=filename)

# --- CANCELLAZIONE DEI SOLI CSV ORIGINALI ---
deleted_count = 0
for filename in os.listdir(dest_folder):
    file_path = os.path.join(dest_folder, filename)
    if os.path.isfile(file_path) and filename.endswith(".csv"):
        os.remove(file_path)
        deleted_count += 1

print(f"Archivio creato: {zip_path}")
print(f"File CSV eliminati dalla cartella {dest_folder}: {deleted_count}")