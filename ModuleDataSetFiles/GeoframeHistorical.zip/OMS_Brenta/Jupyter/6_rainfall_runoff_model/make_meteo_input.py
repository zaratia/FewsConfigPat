import os
import json
import warnings
import numpy as np
import xarray as xr
import argparse

parser = argparse.ArgumentParser()
parser.add_argument("home_dir_mod")
args = parser.parse_args()
# model home dir
# home_dir_mod = "C:/Users/matti/Progetti/02_FEWS_TN/00_FEWS_SA/Modules/OMS_Project_Brenta_TempoRealexFEWS"
home_dir_mod = args.home_dir_mod

# --- CONFIGURAZIONE ---
json_path = os.path.join(
    home_dir_mod, "Jupyter", "6_rainfall_runoff_model", "RRM.json"
)        # percorso al tuo file json
# home dir of the python
home_dir = os.path.abspath(
    os.path.join(os.path.dirname(os.getcwd()), '..')
)  
output_base = os.path.join(home_dir_mod, "output")

precip_nc_path = os.path.join(home_dir, "fews_input", "precipitation.nc")  # file con variabile "tp"
temp_nc_path = os.path.join(home_dir, "fews_input", "temperature.nc")      # file con variabile "ta2m"

# --- LETTURA JSON (per i template dei nomi file) ---
with open(json_path, "r") as f:
    config = json.load(f)

precip_template = config["input_precip_csv"]
temp_template = config["input_temp_csv"]


def split_dataset_by_station(ds, var_name, path_template, home_dir, output_base):
    """
    Divide un dataset (time, stations) in file separati per stazione,
    salvando ognuno secondo il template del path fornito.
    """
    n_stations = ds.dims["stations"]

    for i in range(n_stations):
        # decodifica station_id da bytes a stringa
        station_id_raw = ds["station_id"].values[i]
        if isinstance(station_id_raw, bytes):
            station_id = station_id_raw.decode("utf-8").strip()
        else:
            station_id = str(station_id_raw).strip()

        if not station_id:
            warnings.warn(f"Stazione all'indice {i} ha station_id vuoto, salto.")
            continue

        # costruzione path di destinazione
        dest_path = path_template.replace("${home}", home_dir).replace("${ID}", station_id)
        dest_path = os.path.normpath(dest_path)
        dest_dir = os.path.dirname(dest_path)
        
        if not os.path.isdir(dest_dir):
            warnings.warn(f"Cartella non trovata, la creo: {dest_dir}")
            os.makedirs(dest_dir, exist_ok=True)

        # estrazione dati per la singola stazione
        station_names_raw = ds["station_names"].values[i]
        if isinstance(station_names_raw, bytes):
            station_names_val = station_names_raw
        else:
            station_names_val = str(station_names_raw).encode("utf-8")

        ds_single = xr.Dataset(
            data_vars={
                "x": ("stations", [ds["x"].values[i]]),
                "y": ("stations", [ds["y"].values[i]]),
                "station_id": ("stations", np.array([station_id], dtype="S30")),
                "station_names": ("stations", np.array([station_names_val], dtype="S30")),
                "var": (("time", "stations"), ds[var_name].values[:, i:i+1]),
            },
            coords={
                "time": ds["time"].values,
                "lat": ("stations", [ds["lat"].values[i]]),
                "lon": ("stations", [ds["lon"].values[i]]),
            },
            attrs={
                "Conventions": "CF-1.6",
                "featureType": "timeSeries",
                "coordinate_system": "WGS 1984",
            },
        )

        # attributo standard per la coordinata time
        ds_single["time"].attrs = {
            "standard_name": "time",
            "long_name": "time",
            "axis": "T",
        }
        
        ds_single.to_netcdf(dest_path)
        # print(f"Salvato: {dest_path}")


# --- APERTURA DEI DATASET COMPLESSIVI ---
ds_precip = xr.open_dataset(precip_nc_path)
ds_temp = xr.open_dataset(temp_nc_path)

print("Divisione dataset precipitazione (tp)...")
split_dataset_by_station(ds_precip, "tp", precip_template, home_dir_mod, output_base)

print("/nDivisione dataset temperatura (ta2m)...")
split_dataset_by_station(ds_temp, "ta2m", temp_template, home_dir_mod, output_base)

print("/nFatto!")