import os
import json
import shutil
import argparse
import zipfile
import warnings

# parse init o final forlder
argparse.ArgumentParser()
# Crea il parser
parser = argparse.ArgumentParser(description="")
parser.add_argument("-f", "--folder", type=str, help="initState_files o finalState_files")
parser.add_argument("-m", "--home_dir_mod", type=str, help="model installation directory")
# Leggi gli argomenti dalla riga di comando
args = parser.parse_args()

home_dir_mod = args.home_dir_mod

# 4. Usa il parametro nel codice
print(f"State folder: {args.folder}")
print(f"Model folder: {args.home_dir_mod}")
# --- CONFIGURAZIONE ---
json_path = os.path.join(
    home_dir_mod, "Jupyter", "6_rainfall_runoff_model", "RRM.json"
)        # percorso al tuo file json
home_dir = os.path.abspath(
    os.path.join(os.path.dirname(os.getcwd()), '..')
)  # valore da sostituire a ${home}

output_base = os.path.join(home_dir_mod, "output")  # cartella con le sottocartelle ID
source_folder = os.path.join(home_dir, args.folder)    # cartella unica da cui ripristinare i file

# --- LETTURA JSON ---
with open(json_path, "r") as f:
    config = json.load(f)

# --- TROVA LE CHIAVI CON 'initState' ---
init_state_keys = {k: v for k, v in config.items() if "initState" in k}

print("Chiavi trovate con 'initState':")
for k, v in init_state_keys.items():
    print(f"  {k}: {v}")

# --- TROVA TUTTI GLI ID DISPONIBILI (sottocartelle di output/) ---
if not os.path.isdir(output_base):
    raise FileNotFoundError(f"Cartella non trovata: {output_base}")

ids = [d for d in os.listdir(output_base) if os.path.isdir(os.path.join(output_base, d))]
print(f"\nTrovati {len(ids)} ID: {ids}")

if not os.path.isdir(source_folder):
    raise FileNotFoundError(f"Cartella non trovata: {source_folder}")

# --- ESTRAZIONE DELLO ZIP NELLA CARTELLA SORGENTE ---
zip_path = os.path.join(source_folder, "initState_files.zip")

if os.path.isfile(zip_path):
    print(f"Estrazione di {zip_path}...")
    with zipfile.ZipFile(zip_path, "r") as zipf:
        zipf.extractall(source_folder)
else:
    warnings.warn(f"Archivio zip non trovato: {zip_path}")

# --- COSTRUZIONE PERCORSI E COPIA ---
copied_count = 0
missing_files = []

for id_val in ids:
    for key, template_path in init_state_keys.items():
        # sostituzione dei placeholder per ottenere il percorso di destinazione originale
        real_path = template_path.replace("${home}", home_dir_mod).replace("${ID}", id_val)
        real_path = os.path.normpath(real_path)

        filename = os.path.basename(real_path)
        source_path = os.path.join(source_folder, filename)
        if os.path.isfile(source_path):
            # crea la cartella di destinazione se non esiste
            os.makedirs(os.path.dirname(real_path), exist_ok=True)

            shutil.copy2(source_path, real_path)  # sovrascrive se esiste già
            copied_count += 1
        else:
            missing_files.append(source_path)

print(f"\nFile copiati (con sovrascrittura): {copied_count}")
if missing_files:
    print(f"File non trovati nella cartella sorgente ({len(missing_files)}):")
    # for mf in missing_files:
    #     print(f"  {mf}")
else:
    print("Nessun file mancante, tutto ok!")

# # --- PULIZIA: rimuove i CSV estratti temporaneamente ---
# for filename in os.listdir(source_folder):
#     file_path = os.path.join(source_folder, filename)
#     if os.path.isfile(file_path) and filename.endswith(".csv"):
#         os.remove(file_path)

print("Pulizia CSV temporanei completata.")