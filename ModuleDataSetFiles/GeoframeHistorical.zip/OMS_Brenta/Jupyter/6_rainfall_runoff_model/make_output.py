import os
import numpy as np
import xarray as xr
import argparse

parser = argparse.ArgumentParser()
parser.add_argument("home_dir_mod")
args = parser.parse_args()
# model home dir
# home_dir_mod = "C:/Users/matti/Progetti/02_FEWS_TN/00_FEWS_SA/Modules/OMS_Project_Brenta_TempoRealexFEWS"
home_dir_mod = args.home_dir_mod

# --- CONFIGURAZIONE ---
home_dir = os.path.abspath(
    os.path.join(os.path.dirname(os.getcwd()), '..')
)  # valore da sostituire a ${home}                  # valore da sostituire a ${home}

output_base = os.path.join(home_dir_mod, "output")  # cartella con le sottocartelle ID
dest_folder = os.path.join(home_dir, "fews_output")  # cartella di destinazione
dest_filename = "RRM_Qout_all.nc"

os.makedirs(dest_folder, exist_ok=True)

# --- TROVA TUTTI GLI ID DISPONIBILI (sottocartelle di output/) ---
if not os.path.isdir(output_base):
    raise FileNotFoundError(f"Cartella non trovata: {output_base}")

ids = sorted([d for d in os.listdir(output_base) if os.path.isdir(os.path.join(output_base, d))])
print(f"Trovati {len(ids)} ID: {ids}")

# --- RACCOLTA DEI DATASET SINGOLI ---
datasets = []
missing_files = []

for id_val in ids:
    file_path = os.path.join(output_base, id_val, f"RRM_Qout_{id_val}.nc")

    if os.path.isfile(file_path):
        ds = xr.open_dataset(file_path)
        datasets.append(ds)
    else:
        missing_files.append(file_path)

print(f"\nFile trovati e caricati: {len(datasets)}")
if missing_files:
    print(f"File non trovati ({len(missing_files)}):")
    for mf in missing_files:
        print(f"  {mf}")

if not datasets:
    raise RuntimeError("Nessun file trovato, impossibile procedere.")

# --- UNIONE LUNGO LA DIMENSIONE 'stations' ---
ds_merged = xr.concat(datasets, dim="stations")

# --- RINOMINA DELLA VARIABILE var -> Qout ---
ds_merged = ds_merged.rename({"var": "Qout"})

# --- CHIUSURA DEI DATASET ORIGINALI ---
for ds in datasets:
    ds.close()

# --- ATTRIBUTI GLOBALI ---
ds_merged.attrs = {
    "Conventions": "CF-1.6",
    "title": "GEOframe2027 output",
    "institution": "GEOframe2027",
    "source": "GEOframe2027 simulation",
    "featureType": "timeSeries",
    "coordinate_system": "WGS 1984",
}

# --- SALVATAGGIO ---
dest_path = os.path.join(dest_folder, dest_filename)
ds_merged.to_netcdf(dest_path)

print(f"\nFile unico salvato in: {dest_path}")